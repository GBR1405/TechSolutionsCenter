﻿namespace TechSolutionsCenterAPI.Models
{
    public class RespuestaModel
    {
        public bool Indicador { get; set; }
        public string? Mensaje { get; set; }
        public object? Datos { get; set; }
    }
}
