﻿namespace TechSolutionsCenterAPI.Models
{
    public class GeneroModel
    {

        public long ID_Genero { get; set; }

        public string? Tipo_Genero { get; set; }
    }
}
