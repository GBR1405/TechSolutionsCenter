﻿namespace TechSolutionsCenter.Models
{
    public class CasoFinalizadoModel
    {
        public long ID_CasoAtendido { get; set; }
        public string ComentarioFinal { get; set; }
        public char EstadoFinal { get; set; }
    }
}
